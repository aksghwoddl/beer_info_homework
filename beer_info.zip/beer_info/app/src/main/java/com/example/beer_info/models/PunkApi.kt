package com.example.beer_info.models

class PunkApi {
    companion object{
        const val Domain = "https://api.punkapi.com/v2/"
    }
}