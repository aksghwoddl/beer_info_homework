package com.example.beer_info.models

data class TempX(
    val unit: String,
    val value: Int
)