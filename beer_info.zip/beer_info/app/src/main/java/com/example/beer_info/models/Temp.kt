package com.example.beer_info.models

data class Temp(
    val unit: String,
    val value: Double
)