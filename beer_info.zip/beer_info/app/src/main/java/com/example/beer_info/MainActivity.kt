package com.example.beer_info

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.beer_info.models.BeerModel
import com.example.beer_info.models.PunkApi
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class MainActivity : AppCompatActivity() {
    private  lateinit var mRecyclerView : RecyclerView
    var i = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mRecyclerView = findViewById(R.id.rv_beer_list)
        loadData()

    }

    fun loadData(){
        val retrofit = Retrofit.Builder()
            .baseUrl(PunkApi.Domain)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val service = retrofit.create(RetrofitService::class.java)
        service.getBeer().enqueue(object : Callback<BeerModel>{
            override fun onFailure(call: Call<BeerModel>, t: Throwable) {
                Toast.makeText(this@MainActivity , "에러 발생!" , Toast.LENGTH_LONG).show()
            }

            override fun onResponse(call: Call<BeerModel>, response: Response<BeerModel>) {
//                Log.d("Response ::" , response?.body().toString())

                if(response.isSuccessful){
                    val body = response.body()

                    body?.let {
                        setAdapter(it)

                        mRecyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener(){
                            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                                super.onScrolled(recyclerView, dx, dy)
                                val lastVisibieItemPosition =
                                    (recyclerView.layoutManager as LinearLayoutManager).findLastCompletelyVisibleItemPosition()
                                val itemTotalCount = recyclerView.adapter?.itemCount

                                if(lastVisibieItemPosition  +1 == itemTotalCount){
                                    i++
//                                    Toast.makeText(this@MainActivity , "도착!" , Toast.LENGTH_SHORT).show()
                                    service.getNextPage(i).enqueue(object : Callback<BeerModel>{
                                        override fun onResponse(
                                            call: Call<BeerModel>,
                                            response: Response<BeerModel>
                                        ) {
                                            val body = response?.body()

                                            body.let {
                                                for(i in 0..25)
                                                    it?.add(body?.get(i)!!)
                                                setAdapter(it!!)
                                            }
                                        }

                                        override fun onFailure(call: Call<BeerModel>, t: Throwable) {
                                            Toast.makeText(this@MainActivity , "에러 발생!" , Toast.LENGTH_LONG).show()
                                        }

                                    })

                                }
                            }
                        })
                    }
                }
            }
        })
    }

    private fun setAdapter(beerModels: BeerModel) {
        val mAdapter = RecyclerAdapter(beerModels, this)
        mRecyclerView.adapter = mAdapter
        mRecyclerView.layoutManager = LinearLayoutManager(this)
        mRecyclerView.setHasFixedSize(false)

        mAdapter.setItemClickListener(object : RecyclerAdapter.OnItemClickListener{
            override fun onClick(v: View, position: Int) {
                //Toast.makeText(v.context , "$position 클릭!" , Toast.LENGTH_SHORT).show()
                var intent = Intent(this@MainActivity ,ShowInformActivity::class.java)
                var beerName = beerModels[position].name
                intent.putExtra("beer_name" , beerName)
                startActivity(intent)
            }
        })
    }


}

