package com.example.beer_info.models

class BeerModel : ArrayList<BeerModelItem>(
)

