package com.example.beer_info

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.bumptech.glide.Glide
import com.example.beer_info.models.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

private lateinit var  mName : TextView
private lateinit var  mID : TextView
private lateinit var  mAbv : TextView
private lateinit var  mAttenuationLevel : TextView
private lateinit var  mBrewersTips : TextView
private lateinit var  mContributedBy : TextView
private lateinit var  mDescription : TextView
private lateinit var  mEbc : TextView
private lateinit var  mFirstBrewed : TextView
private lateinit var  mFoodPairing : TextView
private lateinit var  mIbu : TextView
private lateinit var  mIngredients : TextView
private lateinit var  mMethod : TextView
private lateinit var  mPh : TextView
private lateinit var  mSrm : TextView
private lateinit var  mTagLine : TextView
private lateinit var  mTargetFg : TextView
private lateinit var  mTargetOg : TextView
private lateinit var  mVolume : TextView

private lateinit var  mImage : ImageView


class ShowInformActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_inform)
        mName = findViewById(R.id.tv_beer_inform_name)
        mID = findViewById(R.id.tv_beer_inform_id)
        mAbv = findViewById(R.id.tv_beer_inform_abv)
        mAttenuationLevel = findViewById(R.id.tv_beer_inform_attenuation_level)
        mBrewersTips = findViewById(R.id.tv_beer_inform_brewers_tips)
        mContributedBy = findViewById(R.id.tv_beer_inform_contributed_by)
        mDescription = findViewById(R.id.tv_beer_inform_description)
        mEbc = findViewById(R.id.tv_beer_inform_ebc)
        mFirstBrewed = findViewById(R.id.tv_beer_inform_first_brewed)
        mFoodPairing = findViewById(R.id.tv_beer_inform_food_pairing)
        mIbu = findViewById(R.id.tv_beer_inform_ibu)
        mIngredients = findViewById(R.id.tv_beer_inform_ingredients)
        mMethod = findViewById(R.id.tv_beer_inform_method)
        mPh = findViewById(R.id.tv_beer_inform_ph)
        mSrm = findViewById(R.id.tv_beer_inform_srm)
        mTagLine = findViewById(R.id.tv_beer_inform_tag_line)
        mTargetFg = findViewById(R.id.tv_beer_inform_target_fg)
        mTargetOg = findViewById(R.id.tv_beer_inform_target_og)
        mVolume = findViewById(R.id.tv_beer_inform_volume)

        mImage = findViewById(R.id.iv_beer_inform_img)

        val retrofit = Retrofit.Builder()
            .baseUrl(PunkApi.Domain)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val mBeerName = intent.getStringExtra("beer_name").toString()
        val service = retrofit.create(RetrofitService::class.java)
        service.getSelectedBeer(mBeerName).enqueue(object : Callback<BeerModel> {
            override fun onFailure(call: Call<BeerModel>, t: Throwable) {
                Toast.makeText(this@ShowInformActivity, "요청 실패!!", Toast.LENGTH_SHORT).show()
            }

            override fun onResponse(call: Call<BeerModel>, response: Response<BeerModel>) {
                if (response.isSuccessful) {
                    val body = response.body()

                    body.let {
                        Glide.with(this@ShowInformActivity).load(it?.get(0)?.image_url).into(mImage)
                        mName.text = "Name : ${it?.get(0)?.name}"
                        mID.text = "ID : ${it?.get(0)?.id}"
                        mAbv.text = "ABV : ${it?.get(0)?.abv}"
                        mAttenuationLevel.text =
                            "Attenuation Level : ${it?.get(0)?.attenuation_level}"
                        mBrewersTips.text = "Brewers Tips \n${it?.get(0)?.brewers_tips}"
                        mContributedBy.text = "Contributed By : ${it?.get(0)?.contributed_by}"
                        mDescription.text = "Description \n${it?.get(0)?.description}"
                        mEbc.text = "EBC : ${it?.get(0)?.ebc}"
                        mFirstBrewed.text = "First Brewed : ${it?.get(0)?.first_brewed}"
                        mFoodPairing.text = "Food Pairing \n${it?.get(0)?.food_pairing}"
                        mIbu.text = "IBU : ${it?.get(0)?.ibu}"
                        mIngredients.text = "Ingredients : ${it?.get(0)?.ingredients}"
                        mMethod.text = "Method\n" +
                                "${it?.get(0)?.method?.fermentation}\n" +
                                "${it?.get(0)?.method?.mash_temp?.get(0)}\n" +
                                "${it?.get(0)?.method?.twist}"
                        mPh.text = "Ph : ${it?.get(0)?.ph}"
                        mSrm.text = "SRM : ${it?.get(0)?.srm}"
                        mTagLine.text = "Tag Line : ${it?.get(0)?.ph}"
                        mTargetFg.text = "Target FG : ${it?.get(0)?.target_fg}"
                        mTargetOg.text = "Target OG : ${it?.get(0)?.target_og}"
                        mVolume.text =
                            "Volume : ${it?.get(0)?.volume?.value}${it?.get(0)?.volume?.unit} "
                    }
                }
            }
        })
    }
}