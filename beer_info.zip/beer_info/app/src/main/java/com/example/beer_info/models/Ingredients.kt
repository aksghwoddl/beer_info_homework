package com.example.beer_info.models

data class Ingredients(
    val hops: List<Any>,
    val malt: List<Malt>,
    val yeast: String
)