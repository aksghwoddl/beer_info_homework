package com.example.beer_info

import android.content.Context
import android.media.Image
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.beer_info.models.BeerModel
import com.example.beer_info.models.BeerModelItem
class RecyclerAdapter(val beerModels : BeerModel , val context : Context)
    : RecyclerView.Adapter<RecyclerAdapter.ViewHolder>()
{
    class ViewHolder (itemView: View?) : RecyclerView.ViewHolder(itemView!!){
        val thumbnail = itemView?.findViewById<ImageView>(R.id.iv_beer_img)
        val title = itemView?.findViewById<TextView>(R.id.tv_beer_name)
        val mBeerHolder = itemView?.findViewById<LinearLayout>(R.id.ll_beer_holder)
        fun bind(beerModel: BeerModelItem? , context: Context){
            val mImageUrl = beerModel?.image_url.toString()
            if(!mImageUrl.isEmpty()){
//                thumbnail?.setImageResource(R.mipmap.ic_launcher)
                Glide.with(context).load(beerModel?.image_url).into(thumbnail!!)
            }
            else{
                thumbnail?.visibility = View.GONE
            }

            title?.text = beerModel?.name
        }
    }



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return RecyclerAdapter.ViewHolder(LayoutInflater.from(context)
            .inflate(R.layout.beer_holder , parent , false))
    }

    //Click Listener
    interface OnItemClickListener{
        fun onClick(v : View , position : Int)
    }

    private lateinit var itemClickListener: OnItemClickListener

    fun setItemClickListener(itemClickListener: OnItemClickListener) {
        this.itemClickListener = itemClickListener
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.mBeerHolder?.setOnClickListener{
            itemClickListener.onClick(it , position)
        }
        holder.bind(beerModels[position] , context)

    }

    override fun getItemCount(): Int {
        return beerModels.count()
    }

}

