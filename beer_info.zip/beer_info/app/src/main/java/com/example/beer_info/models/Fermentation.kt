package com.example.beer_info.models

data class Fermentation(
    val temp: Temp
)