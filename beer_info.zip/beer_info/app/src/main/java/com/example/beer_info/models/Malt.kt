package com.example.beer_info.models

data class Malt(
    val amount: Amount,
    val name: String
)