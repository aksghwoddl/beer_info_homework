package com.example.beer_info.models

data class BoilVolume(
    val unit: String,
    val value: Int
)