package com.example.beer_info.models

data class Volume(
    val unit: String,
    val value: Int
)