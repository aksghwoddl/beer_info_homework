package com.example.beer_info

import android.telecom.Call
import com.example.beer_info.models.BeerModel
import com.example.beer_info.models.BeerModelItem
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query


interface RetrofitService {
    @GET("beers")
    fun getBeer() : retrofit2.Call<BeerModel>

    @GET("beers")
    fun getSelectedBeer(@Query("beer_name") name : String) : retrofit2.Call<BeerModel>

    @GET("beers")
    fun getNextPage(@Query("page") page : Int) : retrofit2.Call<BeerModel>


}