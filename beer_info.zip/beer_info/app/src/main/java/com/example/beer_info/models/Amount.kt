package com.example.beer_info.models

data class Amount(
    val unit: String,
    val value: Double
)