package com.example.beer_info.models

data class MashTemp(
    val duration: Int,
    val temp: TempX
)